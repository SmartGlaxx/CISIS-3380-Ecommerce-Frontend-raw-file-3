import React, { useEffect } from 'react'
import { Navbar, Sidebar, Footer, Backdrop} from '../../Components'
import { UseAppContext } from '../../Contexts/app-context'
import "./Cart.css"
import { formattedPrice } from '../../resourses/functions'
import { Link } from 'react-router-dom'
import {loadStripe} from '@stripe/stripe-js';
import Axios from "axios"
import API from '../../resourses/api'

const Cart = () => {
  const {loggedIn, currentUserParsed, cart, decreaseCartItem,
  increaseCartItem, deleteCartItem, clearCart} = UseAppContext()
  const urlParams = new URLSearchParams(window.location.search);
  let total = 0

  const payTotal = async () => {
    try {
    
      const stripe = await loadStripe("pk_test_gxfekKu4IwU4ZIVoJ0cG5pb200MfcjbMqA");

    
      const body = {
        products: cart
      };

    
      const headers = {
        "Content-Type": "application/json"
      };

    
      const response = await Axios.post(`${API}/payment/checkout`, body, {
        headers: headers
      });

    
      const session = response.data;

    
      const result = await stripe.redirectToCheckout({
        sessionId: session.id
      });

    
      if (result.error) {
        console.error(result.error);
      }
    } catch (error) {
      console.error(error.message);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  
  if (urlParams.has('clearCart')) {
    clearCart();
  }


  return (
    <div>
      
      <Navbar />
      <Sidebar />
      <Backdrop />
      {loggedIn == "true" ?
      <div className={cart.length > 0 ? "cart" : 'empty-cart-page'}>
        <h3>Cart</h3>
        {
          
          cart.length > 0 ? 
          <div >
          {
          cart.map(cartItem=>{
            const {id, productName, selectedColor, quantity, inventory, image, price} = cartItem
            
            total += (quantity * price)
            return <div className='cart-item' key={id}>
              <Link to={`/product/${id}`} className='link-to-product'>
                <img src={image} alt={`img_${id}`} className='cart-image'/>
              </Link>
              <h4 className='cart-product-name'>{productName}</h4><button className='delete-cart-item' onClick={()=>deleteCartItem(id)}>Delete</button>
              <div className='cart-product-color'>Color: <div style={{background: `${selectedColor}`}} 
              className='cart-color'></div>{selectedColor}</div>
              <div className='cart-product-quntity'>Quantity: 
              <div className='cart-quntity-items'>
                <button className='cart-quntity-button' onClick={()=>decreaseCartItem (cartItem)}>-</button>
                <div className='cart-quntity'>{quantity}</div>
                <button className='cart-quntity-button' onClick={()=>increaseCartItem (cartItem)}>+</button>
              </div>
              </div>
              <div className='cart-product-inventory'>Available: {inventory}</div>
              <div className='cart-product-price'>Unit price: <span className='cart-product-price-2'>{formattedPrice(price)}</span></div>
              <div className='cart-product-subtotal'>Sub total: <span className='cart-product-subtotal-2'>{formattedPrice(price * quantity)}</span></div>
            </div>
          })
        }

          <div className='cart-total'>Total: {formattedPrice(total)}</div>
          
          <div className='cart-option-buttons'>
            <div>
            <button className='clear-cart' onClick={clearCart}>Clear Cart</button>
            <Link to={"/products"}><button className='continue-shopping'>Continue Shopping</button></Link>
            </div>
            <button onClick={()=>payTotal(cart)}
            className='pay-button'>Pay {formattedPrice(total)}</button>
          </div>
          </div>
          : <div ><div className='empty-cart'>Your cart is empty. 
            <Link to={`/products`} className='empty-cart-link'>Start shopping</Link>
          </div></div>
        }
      </div>
    : <div>Log in</div>}
      <Footer />
      </div>

  )
}

export default Cart