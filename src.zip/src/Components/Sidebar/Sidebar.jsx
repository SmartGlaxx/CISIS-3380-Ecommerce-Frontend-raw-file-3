import React from 'react'
import { links } from '../../resourses/links'
import { Link } from 'react-router-dom'
import { UseAppContext } from '../../Contexts/app-context'
import "./Sidebar.css"


const Sidebar = () => {
  const {sidebarOpen, openSidebar, loggedIn, setLoggedIn} = UseAppContext()
  
  return (
    <div className={sidebarOpen ? "sidebar-open" : "sidebar-closed"}>
      <ul className='nav-links-mobile'>
        {
          links.map(link =>{
            const {id, name, url, icon} = link
            return <li key={id} className='nav-link-mobile'>
              <Link to={`${url}`} className='link' onClick={openSidebar}>
                <span className='sidebar-link-name'>
                {name}{icon}
               </span>
                </Link>
            </li>
          })
        }
        </ul>
        <hr />
        {
          
          loggedIn == "true" && <button className='sign-out-button-mobile' onClick={()=>setLoggedIn(false)}>Sign out</button>
        }
    </div>
  )
}

export default Sidebar